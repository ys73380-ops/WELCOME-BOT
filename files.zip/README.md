# 🌹 Welcome Bot — Setup Guide

## Kya Kya Features Hain?

| Feature | Detail |
|---|---|
| 🧠 Gender Detection | GROQ LLaMA3 se naam dekh ke real-time detect |
| 👦👧 Alag Welcome | Male/Female ke liye alag message + video |
| 🎲 Random Rotation | Multiple messages/videos mein se random pick |
| ✏️ Exact Formatting | Jo likha waisa hi send hoga |
| 🔘 Inline Buttons | Custom buttons welcome message mein |
| 📦 Multi-Group | Ek bot se multiple groups manage |

---

## Setup Steps

### Step 1 — Python Install Karo
```
Python 3.10+ chahiye
```

### Step 2 — Dependencies Install Karo
```bash
pip install -r requirements.txt
```

### Step 3 — Keys Set Karo

**`.env.example` ko copy karo:**
```bash
cp .env.example .env
```

**`.env` file kholo aur fill karo:**
```
BOT_TOKEN=123456:ABC-your-token
GROQ_API_KEY=gsk_your-groq-key
```

**BOT_TOKEN kahan se milega?**
→ Telegram pe @BotFather se `/newbot` karke

**GROQ_API_KEY kahan se milega?**
→ https://console.groq.com pe free account banao

### Step 4 — BotFather Settings
BotFather pe `/mybots` → apna bot → Bot Settings:
- **Group Privacy = DISABLE karo** (warna group messages nahi aayenge)

### Step 5 — Bot Chalao
```bash
# Linux/Mac
export BOT_TOKEN="your_token"
export GROQ_API_KEY="your_key"
python bot.py

# Windows
set BOT_TOKEN=your_token
set GROQ_API_KEY=your_key
python bot.py
```

---

## Bot Use Kaise Karein?

### Step 1 — Group mein add karo
Bot ko group mein add karo aur **Admin** banao.

### Step 2 — Connect karo
Group mein type karo:
```
/connect
```

### Step 3 — DM mein jao
Bot ke DM mein jao aur messages set karo:

```
/set_male   → Male welcome message + video set karo
/set_female → Female welcome message + video set karo
/add_more   → Aur messages/videos add karo (random rotation ke liye)
```

### Step 4 — Test karo
```
/preview → DM mein preview dekho
```

---

## Message Placeholders

Welcome message mein ye use kar sakte ho:

| Placeholder | Example Output |
|---|---|
| `{name}` | Rahul |
| `{mention}` | [Rahul](tg://user?id=123) (clickable) |
| `{username}` | @rahul123 |
| `{gender}` | 👦 Male / 👧 Female |

**Example Message:**
```
🌹 Welcome {mention}!

Hamare group mein aapka swagat hai! 🎉
Aap {gender} hain aur aapka naam {name} hai.

Rules padh lo: t.me/ourrules
```

---

## Saari Commands

| Command | Kahan | Kya Karta Hai |
|---|---|---|
| `/connect` | Group | Bot ko group se connect karo |
| `/start` | DM | Bot info dekho |
| `/set_male` | DM | Male message + video set karo |
| `/set_female` | DM | Female message + video set karo |
| `/add_more` | DM | Aur messages/videos add karo |
| `/listmedia` | DM | Media count dekho |
| `/clearmedia` | DM | Sab media clear karo |
| `/preview` | DM | Welcome message test karo |
| `/settings` | DM | Current settings dekho |
| `/setbuttons` | DM | Inline buttons add karo |
| `/reset` | DM | Sab settings delete karo |
| `/skip` | DM | Video skip karo (conversation mein) |
| `/cancel` | DM | Conversation cancel karo |

---

## VPS pe Deploy Karna (24/7 Running)

```bash
# systemd service banao
sudo nano /etc/systemd/system/welcomebot.service
```

```ini
[Unit]
Description=Welcome Bot
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/welcome_bot
Environment=BOT_TOKEN=your_token
Environment=GROQ_API_KEY=your_key
ExecStart=/usr/bin/python3 bot.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable welcomebot
sudo systemctl start welcomebot
sudo systemctl status welcomebot
```

---

## Data Kahan Store Hota Hai?

Sab kuch `data.json` file mein save hota hai bot ke folder mein.
